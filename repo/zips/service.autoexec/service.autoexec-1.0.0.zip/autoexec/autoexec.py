import xbmc
xbmc.executebuiltin( "ActivateWindow(Videos,plugin://plugin.video.netflix)" )